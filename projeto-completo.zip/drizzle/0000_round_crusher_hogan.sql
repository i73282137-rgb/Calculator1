CREATE TABLE `sync_sessions` (
	`key_hash` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`updated_at` integer NOT NULL
);
