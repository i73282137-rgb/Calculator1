import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const syncSessions = sqliteTable('sync_sessions', {
  keyHash: text('key_hash').primaryKey(),
  payload: text('payload').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
